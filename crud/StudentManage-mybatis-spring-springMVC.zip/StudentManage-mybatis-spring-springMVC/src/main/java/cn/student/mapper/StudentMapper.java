package cn.student.mapper;

import cn.student.pojo.Student;

import java.util.List;

public interface StudentMapper {
    int countStudent();
    Student getStudentById(int id);
    int addStudent(Student student);
    int deleteStudent(int id);
    List<Student> getStudentList();
    int putStudent(Student student);
}
