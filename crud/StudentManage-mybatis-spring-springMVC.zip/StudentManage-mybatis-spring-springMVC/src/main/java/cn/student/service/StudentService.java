package cn.student.service;

import cn.student.mapper.StudentMapper;
import cn.student.pojo.Student;
import cn.student.util.Tuple;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
@Service("studentService")
public class StudentService {

    private StudentMapper studentMapper;
    public StudentMapper getStudentMapper() {
        return studentMapper;
    }
    @Autowired
    @Qualifier("studentMapper")
    public void setStudentMapper(StudentMapper studentMapper) {
        this.studentMapper = studentMapper;
    }

    public int countStudent() {
        int counted = studentMapper.countStudent();
        return counted;
    }
    public Student getStudentById(int id) {
        Student student = studentMapper.getStudentById(id);
        return student;
    }
    public Student addStudent(Student student) {
        int added = studentMapper.addStudent(student);
        if(added > 0) {
            return student;
        }
        return null;
    }
    public Student deleteStudent(int id) {
        Student student = studentMapper.getStudentById(id);
        int deleted = studentMapper.deleteStudent(student.getSid());
        if(deleted < 0) {
            return null;
        }
        return student;
    }
    public List<Student> getStudentList() {
        return studentMapper.getStudentList();
    }
    public Student putStudent(int id,String setting,List<Object> args) {
        Student student = studentMapper.getStudentById(id);
        String[] groups = setting.split(",");
        List<String> groupKey = new ArrayList<>();
        for(String s : groups) {
            groupKey.add(s.split("=")[0].trim());
        }
        List<Tuple> tuples = new ArrayList<>();
        for(int i = 0; i < groupKey.size(); i++) {
            tuples.add(new Tuple(groupKey.get(i),args.get(i)));
        }
        Field[] fields = Student.class.getDeclaredFields();
        for(Field field : fields) {
            for(Tuple tuple : tuples) {
                if(field.getName().equals(tuple.getKey())) {
                    Method method = null;
                    try {
                        method = Student.class.getMethod("set" + tuple.getKey().substring(0,1).toUpperCase() + tuple.getKey().substring(1),tuple.getValue().getClass());
                        method.invoke(student,tuple.getValue());
                    } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        }
        int put = studentMapper.putStudent(student);
        if(put > 0) {
            return student;
        }
        return null;
    }
    public Student putStudent(Student student) {
        int put = studentMapper.putStudent(student);
        return student;
    }
}
