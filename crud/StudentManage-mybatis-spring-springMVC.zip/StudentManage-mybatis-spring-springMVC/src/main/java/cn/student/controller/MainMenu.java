package cn.student.controller;

import cn.student.pojo.Student;
import cn.student.service.StudentService;
import cn.student.util.DatabaseUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.dbcp.BasicDataSource;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
@Controller
public class MainMenu {
    private ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationConfig.xml");
    private StudentService service = (StudentService) context.getBean("studentService");
    private Scanner scaner = new Scanner(System.in);

    public SqlSession getSqlSession() {
        SqlSessionFactory sqlSessionFactory = (SqlSessionFactory) this.context.getBean("sqlSessionFactory");
        return sqlSessionFactory.openSession();
    }
    public PlatformTransactionManager getTransactionManager() {
        BasicDataSource dataSource = (BasicDataSource) context.getBean("dataSource");
        PlatformTransactionManager transactionManager = new DataSourceTransactionManager(dataSource);
        return transactionManager;
    }
    public TransactionStatus getTransactionStatus(PlatformTransactionManager transactionManager) {
        TransactionDefinition define = new DefaultTransactionDefinition();
        TransactionStatus status = transactionManager.getTransaction(define);
        return status;
    }
    @PostMapping("/add")
    @ResponseBody
    public String addStudent(@RequestBody Student student) {
        student.setSid(service.countStudent() + 1);
        SqlSession sqlSession = getSqlSession();
        PlatformTransactionManager transactionManager = getTransactionManager();
        TransactionStatus status = getTransactionStatus(transactionManager);
        System.out.println(student);
        Student stu = service.addStudent(student);
        if(stu != null) {
            transactionManager.commit(status);
            sqlSession.close();
            return "{status:-1,message:学生信息添加成功！}";
        }
        transactionManager.rollback(status);
        sqlSession.close();
        return "{status:-1,message:学生信息添加失败！}";
    }
    public void addStudent() {
        Date date = null;
        SqlSession sqlSession = getSqlSession();
        PlatformTransactionManager transactionManager = getTransactionManager();
        TransactionStatus status = getTransactionStatus(transactionManager);
        System.out.print("请输入学生姓名：");
        String sName = scaner.next();
        System.out.print("请输入学生年龄：");
        int sAge = scaner.nextInt();
        scaner.nextLine();
        System.out.print("请输入学生生日（yyyy-MM-dd）：");
        String birthday = scaner.nextLine();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            date = sdf.parse(birthday);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        Student student = new Student(sName,sAge,date);
        int size = service.countStudent();
        student.setSid(size + 1);
        Student stu = service.addStudent(student);
        if(stu != null) {
            transactionManager.commit(status);
            sqlSession.close();
            System.out.println("学生信息添加成功！");
            return;
        }
        transactionManager.rollback(status);
        sqlSession.close();
        System.out.println("学生信息添加失败!");
    }
    @GetMapping("/delete/{sid}")
    @ResponseBody
    public String deleteStudent(@PathVariable Integer sid) {
        PlatformTransactionManager transactionManager = getTransactionManager();
        TransactionStatus status = getTransactionStatus(transactionManager);
        SqlSession sqlSession = getSqlSession();
        Student student = service.getStudentById(sid);
        if(student != null) {
            System.out.println(student.getSid());
            Student stu = service.deleteStudent(student.getSid());
            if(stu != null) {
                transactionManager.commit(status);
                sqlSession.close();
                System.out.println("学生信息删除成功！");
                return "{status:0,message:OK}";
            } else {
                transactionManager.rollback(status);
                sqlSession.close();
                return "{status:-1,message:删除失败！}";
            }
        }
        transactionManager.rollback(status);
        sqlSession.close();
        return "{status:-1,message:没有这个学生！}";
    }
    public void deleteStudent() {
        this.listStudent();
        SqlSession sqlSession = getSqlSession();
        PlatformTransactionManager transactionManager = getTransactionManager();
        TransactionStatus status = getTransactionStatus(transactionManager);
        System.out.print("请输入要删除的学生编号：");
        int id = scaner.nextInt();
        Student student = service.deleteStudent(id);
        if (student != null) {
            transactionManager.commit(status);
            sqlSession.close();
            System.out.println("学生信息删除成功！");
            return;
        }
        transactionManager.rollback(status);
        sqlSession.close();
        System.out.println("学生信息删除失败！");
    }
    @GetMapping("/list")
    @ResponseBody
    public String listStudent() {
        ObjectMapper objectMapper = new ObjectMapper();
        SqlSession sqlSession = getSqlSession();
        System.out.println("学生信息如下：");
        System.out.print("编号\t\t姓名\t\t年龄\t\t生日\n");
        List<Student> students = service.getStudentList();
        for(Student student : students) {
            System.out.printf("%d\t\t%s\t\t%d\t\t%s\n",student.getSid(),student.getName(),student.getAge(), new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(student.getBirthday()));
        }
        sqlSession.close();
        String json = null;
        try {
            json = objectMapper.writeValueAsString(students);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        return json;
    }

    public void updateStudent() {
        boolean stop = false;
        PlatformTransactionManager transactionManager = getTransactionManager();
        TransactionStatus status = getTransactionStatus(transactionManager);
        SqlSession sqlSession = getSqlSession();
        List<Object> args = new ArrayList<>();
        StringJoiner joiner = new StringJoiner(",");
        this.listStudent();
        System.out.print("请输入要修改的学生编号：");
        int id = scaner.nextInt();
        System.out.println("可以修改的属性名称如下：");
        List<String> attrNames = DatabaseUtil.getAttrName(Student.class);
        for(String attrName : attrNames) {
            System.out.print(attrName + "    ");
        }
        System.out.print("\n");
        do {
            System.out.print("请输入要修改的学生信息属性：");
            String attN = scaner.next();
            System.out.print("请输入修改后的值：");
            switch(attN.trim()) {
                case "name" : {
                    joiner.add(attN + " = ? ");
                    args.add(scaner.next());
                    break;
                }
                case "age": {
                    joiner.add(attN + " = ? ");
                    args.add(scaner.nextInt());
                    break;
                }
                case "birthday" : {
                    joiner.add(attN + " = ? ");
                    try {
                        scaner.nextLine();
                        String date = scaner.nextLine();
                        args.add(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(date));
                    } catch (ParseException e) {
                        transactionManager.rollback(status);
                        sqlSession.close();
                        throw new RuntimeException(e);
                    }
                    break;
                }
                default: {
                    System.out.println("输入错误！");
                    continue;
                }
            }
            // System.out.println(joiner.toString());
            System.out.print("是否修改其他属性？(true/false):");
            String temp = scaner.next();
            if("false".equals(temp)) {
                stop = true;
            }
        } while (!stop);
        String setting = joiner.toString();
        Student student = service.putStudent(id, setting, args);
        if(student != null) {
            transactionManager.commit(status);
            sqlSession.close();
            System.out.println("学生信息修改成功！");
            return;
        }
        transactionManager.rollback(status);
        sqlSession.close();
        System.out.println("学生信息修改失败！");
    }
    @PostMapping("/update")
    //@RequestMapping(value = "/update",method = {RequestMethod.POST})
    @ResponseBody
    public String updateStudent(@RequestBody Student stu) {
        Student temp = new Student(stu.getSid(),stu.getName(), stu.getAge(), stu.getBirthday());
        PlatformTransactionManager transactionManager = getTransactionManager();
        TransactionStatus status = getTransactionStatus(transactionManager);
        SqlSession sqlSession = getSqlSession();
        Student student = service.putStudent(temp);
        if(student != null) {
            transactionManager.commit(status);
            sqlSession.close();
            System.out.println("学生信息修改成功！");
            return "{status:0,message:OK}";
        }
        transactionManager.rollback(status);
        sqlSession.close();
        System.out.println("学生信息修改失败！");
        return "{status:-1,message:学生信息修改失败！}";
    }

    public boolean printMenu() {
        boolean flag = false;
        System.out.println("-----------欢迎来到学生管理系统------------");
        System.out.println("1.添加学生");
        System.out.println("2.删除学生");
        System.out.println("3.修改学生");
        System.out.println("4.查看所有学生");
        System.out.println("5.退出");
        System.out.print("请选择：");
        int i = scaner.nextInt();
        switch(i) {
            case 1 : {
                System.out.println("添加学生");
                this.addStudent();
                break;
            }
            case 2 : {
                System.out.println("删除学生");
                this.deleteStudent();
                this.listStudent();
                break;
            }
            case 3 : {
                System.out.println("修改学生");
                this.updateStudent();
                this.listStudent();
                break;
            }
            case 4 : {
                System.out.println("查看所有学生");
                this.listStudent();
                break;
            }
            case 5 : {
                System.out.println("感谢使用！");
                flag = true;
                break;
            }
            default:{
                System.out.println("输入错误！");
            }
        }
        return flag;
    }
    public static void main(String[] args) {
        MainMenu mainMenu = new MainMenu();
        while(true) {
            if(mainMenu.printMenu()) {
                break;
            }
        }
    }
}
