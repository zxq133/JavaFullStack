package cn.student.service;

import cn.student.pojo.Student;

import java.sql.ResultSet;
import java.util.List;
public interface StudentService {


    Student addStudent(Student student);
    Student deleteStudent(int id);
    List<Student> getStudentList();
    Student putStudent(int id,String setting,List<Object> args);
}
