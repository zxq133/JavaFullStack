package cn.student.service.impl;

import cn.student.dao.StudentDao;
import cn.student.dao.impl.StudentDaoImpl;
import cn.student.pojo.Student;
import cn.student.service.StudentService;
import cn.student.util.DataBaseUtil;

import java.sql.ResultSet;
import java.util.List;

public class StudentServiceImpl implements StudentService {
    private StudentDao studentDao = new StudentDaoImpl();
    @Override
    public Student addStudent(Student student) {
        if(studentDao.addStudent(student) > 0) {
           return student;
        }
        return null;
    }

    @Override
    public Student deleteStudent(int id) {
        if(studentDao.deleteStudent(id) > 0) {
            List<Student> students = this.getStudentList();
            for(Student student : students) {
                if(student.getSid() == id) {
                    return student;
                }
            }
        }
        return null;
    }

    @Override
    public List<Student> getStudentList() {
        ResultSet studentList = studentDao.getStudentList();
        return DataBaseUtil.implEntitySetter(studentList, Student.class);
    }

    @Override
    public Student putStudent(int id,String setting,List<Object> args) {
        if(studentDao.putStudent(id,setting,args) > 0) {
            List<Student> students = this.getStudentList();
            for(Student student : students) {
                if(id == student.getSid()) {
                   return student;
                }
            }
        }
        return null;
    }
}
