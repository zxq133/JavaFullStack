package cn.student.util;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.*;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.Date;

public class DataBaseUtil {
    private static Connection conn;
    private static String[] info = null;
    private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle("cn.student.resources.student-db");
    static {
        String driver = RESOURCE_BUNDLE.getString("student.driver");
        String url = RESOURCE_BUNDLE.getString("student.url");
        String username = RESOURCE_BUNDLE.getString("student.username");
        String password = RESOURCE_BUNDLE.getString("student.password");
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        setDatabaseInfo(new String[]{url,username,password});
    }

    public static void setDatabaseInfo(String[] data) {
        info = data;
    }

    public static Connection getConnection() {
        try {
            conn = DriverManager.getConnection(info[0], info[1], info[2]);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return conn;
    }

    public static void closeResource(ResultSet rs, Statement stmt) {
        try{
            rs.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        try{
            stmt.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public static void closeConnection(Connection conn) {
        try {
            conn.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // 测试获取连接对象
    //public static void main(String[] args) {
    //    DataBaseUtil a = new DataBaseUtil();
    //    System.out.println(a.getConnection());
    //}

    public static String getEntityColString(Class<?> objClass,boolean isAttr) {
        String suffixTableName = objClass.getSimpleName().toLowerCase();
        String tableName = "t_" + suffixTableName;
        Field[] fields = objClass.getDeclaredFields();
        StringJoiner joiner = new StringJoiner(",");
        for(Field field : fields) {
            if(isAttr) {
                joiner.add("`"+field.getName()+"`");
                continue;
            }
            joiner.add(tableName + "." + field.getName());
        }
        return joiner.toString();
    }
    public static <T> Object[] getEntityAttrObjArray(T obj,Class<T> objClass) {
        Field[] fields = objClass.getDeclaredFields();
        Method[] methods = objClass.getDeclaredMethods();
        Object[] values = new Object[fields.length];
        int i = 0;
        for(Field field : fields) {
            String setterName = "get" + field.getName().substring(0,1).toUpperCase() + field.getName().substring(1);
            for(Method method : methods) {
                String methodName = method.getName();
                if(setterName.equals(methodName)) {
                    try {
                        values[i] = method.invoke(obj);
                    } catch (IllegalAccessException | InvocationTargetException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
            i += 1;
        }
        return values;
    }
    public static List<String> getAttrName(Class<?> objClass) {
        List<String> list = new ArrayList<>();
        Field[] fields = objClass.getDeclaredFields();
        for (Field field : fields) {
            if(field.getName().contains("id")) {
                continue;
            }
            list.add(field.getName());
        }
        return list;
    }
    // 将ResultSet中的数据映射为对象数组
    public static <T> List<T> implEntitySetter(ResultSet rs, Class<T> objClass) {
        List<T> objList = new ArrayList<>();
        Field[] fields = objClass.getDeclaredFields();
        Method[] methods = objClass.getDeclaredMethods();
        int count = 0;
        try {
            count = rs.getMetaData().getColumnCount();
            while (rs.next()) {
                Object rsObject = null;
                Method setterMethod = null;
                T newObj = objClass.newInstance();
                for(Field field : fields) {
                    String setterName = "set" + field.getName().substring(0,1).toUpperCase() + field.getName().substring(1);
                    for(Method method : methods) {
                        String methodName = method.getName();
                        // 找到了与属性对应的setter方法
                        if(setterName.equals(methodName)) {
                            setterMethod = method;
                            break;
                        }
                    }
                    for(int i = 0; i < count; i++) {
                        // 在ResultSet结果集中获取到了属性对应的值
                        if(rs.getMetaData().getColumnName((i+1)).equals(field.getName())) {
                            rsObject = rs.getObject((i+1));
                            break;
                        }
                    }
                    if(setterMethod != null && rsObject != null) {
                        Class<?> paraClass = setterMethod.getParameterTypes()[0];
                        try {
                            setterMethod.invoke(newObj,paraClass.cast(rsObject));
                        } catch(ClassCastException e) {
                            LocalDateTime localDateTime = (LocalDateTime) rsObject;
                            Instant instant = localDateTime.atZone(ZoneId.systemDefault()).toInstant();
                            Date date = Date.from(instant);
                            setterMethod.invoke(newObj,paraClass.cast(date));
                        }
                    }
                }
                objList.add(newObj);
            }
        } catch (SQLException | InvocationTargetException | InstantiationException | IllegalAccessException ex) {
            throw new RuntimeException(ex);
        }
        return objList;
    }
}
