package cn.student.dao;

import cn.student.pojo.Student;

import java.sql.ResultSet;
import java.util.List;

public interface StudentDao {
    int countStudent();
    int addStudent(Student student);
    int deleteStudent(int id);
    ResultSet getStudentList();
    int putStudent(int id, String setting, List<Object> args);
}
