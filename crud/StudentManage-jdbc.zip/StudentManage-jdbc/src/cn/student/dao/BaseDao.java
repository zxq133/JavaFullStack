package cn.student.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public interface BaseDao {
    String generateSql(String dml, String table, String cols,String setting, String condition);
    Statement createStatement(Connection conn,String sql,Object[] args);
    int executeUpdateSql(PreparedStatement stmt);
    ResultSet executeQuerySql(PreparedStatement stmt);
}
