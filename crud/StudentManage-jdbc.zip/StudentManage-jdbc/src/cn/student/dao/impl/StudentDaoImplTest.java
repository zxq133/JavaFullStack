package cn.student.dao.impl;

import cn.student.dao.StudentDao;
import cn.student.pojo.Student;
import cn.student.util.DataBaseUtil;
import org.junit.Test;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;

public class StudentDaoImplTest {
    private StudentDao studentDaoImpl = new StudentDaoImpl();
    @Test
    public void addStudent() {
        int added = studentDaoImpl.addStudent(new Student(studentDaoImpl.countStudent() + 1, "里斯", 25, new Date()));
        if(added>0) {
            System.out.println("student added!");
        }
    }

    @Test
    public void deleteStudent() {
        int id = 7;
        int deleted = studentDaoImpl.deleteStudent(id);
        if (deleted>0) {
            System.out.println("user deleted!");
        }
    }

    @Test
    public void getStudentList() {
        ResultSet studentList = studentDaoImpl.getStudentList();
        List<Student> students = DataBaseUtil.implEntitySetter(studentList, Student.class);
        for(Student student : students) {
            System.out.println(student);
        }
    }

    @Test
    public void putStudent() {
        int id = 7;
        String setting = "name = ?";
        List<Object> args = new ArrayList<>();
        args.add("小雪");
        int put = studentDaoImpl.putStudent(id, setting, args);
        if (put > 0) {
            System.out.println("user updated!");
        }
    }

    @Test
    public void countStudent() {
        int counted = studentDaoImpl.countStudent();
        System.out.println(counted);
    }
}