package cn.student.dao.impl;

import cn.student.dao.StudentDao;
import cn.student.pojo.Student;
import cn.student.util.DataBaseUtil;

import java.lang.reflect.Field;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentDaoImpl extends BaseDaoImpl implements StudentDao {
    @Override
    public int countStudent() {
        int counted = -1;
        String sql = this.generateSql("select", "t_student", "count(*)", null, null);
        Connection conn = DataBaseUtil.getConnection();
        PreparedStatement statement = this.createStatement(conn, sql, null);
        // System.out.println(statement);
        ResultSet rs = this.executeQuerySql(statement);
        try {
            while (rs.next()) {
                counted = rs.getInt(1);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return counted;
    }

    @Override
    public int addStudent(Student student) {
        String sql = this.generateSql("insert", "t_student", DataBaseUtil.getEntityColString(Student.class,true), null, null);
        Connection conn = DataBaseUtil.getConnection();
        student.setSid(this.countStudent()+1);
        Object[] args = DataBaseUtil.getEntityAttrObjArray(student, Student.class);
        PreparedStatement statement = this.createStatement(conn, sql, args);
        // System.out.println(statement);
        return this.executeUpdateSql(statement);
    }

    @Override
    public int deleteStudent(int id) {
        String sql = this.generateSql("delete", "t_student", null, null, "sid = ?");
        Connection conn = DataBaseUtil.getConnection();
        Object[] args = {id};
        PreparedStatement statement = this.createStatement(conn, sql, args);
        // System.out.println(statement);
        return this.executeUpdateSql(statement);
    }

    @Override
    public ResultSet getStudentList() {
        String sql = this.generateSql("select", "t_student", DataBaseUtil.getEntityColString(Student.class,true), null, null);
        Connection conn = DataBaseUtil.getConnection();
        PreparedStatement statement = this.createStatement(conn, sql, null);
        // System.out.println(statement);
        return this.executeQuerySql(statement);
    }

    @Override
    public int putStudent(int id,String setting,List<Object> args) {
        boolean find = false;
        String sql = this.generateSql("update", "t_student", null, setting, "sid = ?");
        Connection conn = DataBaseUtil.getConnection();
        Field[] fields = Student.class.getDeclaredFields();
        String[] groups = setting.split(",");
        for (Field field : fields) {
            for (String group : groups) {
                // System.out.println(group.split("=")[0].trim() + " " + field.getName());
                if(group.split("=")[0].trim().equals(field.getName())) {
                    // System.out.println(group.split("=")[0].trim() + " " + field.getName());
                    find = true;
                    break;
                }
            }
        }
        if(!find) {
            throw new RuntimeException("没有这个属性！");
        }
        args.add(id);
        int size = args.size();
        PreparedStatement statement = this.createStatement(conn, sql, args.toArray(new Object[size]));
        // System.out.println(statement);
        return this.executeUpdateSql(statement);
    }
}
