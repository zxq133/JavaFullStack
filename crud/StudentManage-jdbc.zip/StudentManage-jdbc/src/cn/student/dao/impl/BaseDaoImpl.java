package cn.student.dao.impl;

import cn.student.dao.BaseDao;

import java.lang.reflect.Field;
import java.sql.*;
import java.util.StringJoiner;

public class BaseDaoImpl implements BaseDao {

    @Override
    public String generateSql(String dml, String table, String cols,String setting, String condition) {
        StringJoiner joiner = new StringJoiner(" ");
        switch(dml) {
            case "select" : {
                joiner.add(dml);
                joiner.add(cols);
                joiner.add("from");
                joiner.add(table);
                if (condition != null) {
                    joiner.add("where");
                    joiner.add(condition);
                }
                break;
            }
            case "insert" : {
                joiner.add(dml);
                joiner.add("into");
                joiner.add(table);
                joiner.add("(");
                joiner.add(cols);
                joiner.add(")");
                joiner.add("value (");
                int length = cols.split(",").length;
                StringJoiner valueFormat = new StringJoiner(",");
                for(int i = 0; i < length; i++) {
                    valueFormat.add("?");
                }
                joiner.add(valueFormat.toString().trim());
                joiner.add(")");
                break;
            }
            case "delete" : {
                joiner.add("delete from");
                joiner.add(table);
                joiner.add("where");
                joiner.add(condition);
                break;
            }
            case "update" : {
                joiner.add("update");
                joiner.add(table);
                joiner.add("set");
                joiner.add(setting);
                joiner.add("where");
                joiner.add(condition);
                break;
            }
        }
        return joiner.toString();
    }
    @Override
    public PreparedStatement createStatement(Connection conn, String sql, Object[] args) {
        PreparedStatement prepared = null;
        try {
            prepared = conn.prepareStatement(sql);
            if(args != null && args.length>0) {
                for(int i = 0; i < args.length; i++) {
                    prepared.setObject((i+1),args[i]);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return prepared;
    }

    @Override
    public int executeUpdateSql(PreparedStatement stmt) {
        int update = -1;
        try {
            update = stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return update;
    }

    @Override
    public ResultSet executeQuerySql(PreparedStatement stmt) {
        ResultSet rs = null;
        try {
            rs = stmt.executeQuery();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return rs;
    }
}
