package cn.student.service;

import cn.student.mapper.StudentMapper;
import cn.student.pojo.Student;
import cn.student.pojo.Tuple;
import cn.student.util.MybatisUtil;
import org.apache.ibatis.session.SqlSession;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class StudentService {
    private StudentMapper studentDao;

    public StudentMapper getStudentDao() {
        return studentDao;
    }

    public void setStudentDao(StudentMapper studentDao) {
        this.studentDao = studentDao;
    }

    public int countStudent() {
        return studentDao.countStudent();
    }
    public Student getStudentById(int id) {
        return studentDao.getStudentById(id);
    }
    public Student addStudent(Student student) {
        int added = studentDao.addStudent(student);
        if(added > 0) {
            return student;
        }
        return null;
    }
    public Student deleteStudent(int id) {
        Student student = studentDao.getStudentById(id);
        int deleted = studentDao.deleteStudent(student.getSid());
        if(deleted > 0) {
            return null;
        }
        return student;
    }
    public List<Student> getStudentList() {
        return studentDao.getStudentList();
    }
    public Student putStudent(int id,String setting,List<Object> args) {
        Student student = studentDao.getStudentById(id);
        String[] groups = setting.split(",");
        List<String> groupKey = new ArrayList<>();
        for(String s : groups) {
            groupKey.add(s.split("=")[0].trim());
        }
        List<Tuple> tuples = new ArrayList<>();
        for(int i = 0; i < groupKey.size(); i++) {
            tuples.add(new Tuple(groupKey.get(i),args.get(i)));
        }
        Field[] fields = Student.class.getDeclaredFields();
        for(Field field : fields) {
            for(Tuple tuple : tuples) {
                if(field.getName().equals(tuple.getKey())) {
                    Method method = null;
                    try {
                        method = Student.class.getMethod("set" + tuple.getKey().substring(0,1).toUpperCase() + tuple.getKey().substring(1),tuple.getValue().getClass());
                        method.invoke(student,tuple.getValue());
                    } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        }
        int put = studentDao.putStudent(student);
        if(put > 0) {
            return student;
        }
        return null;
    }
}
