package cn.student.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class DatabaseUtil {
    public static List<String> getAttrName(Class<?> objClass) {
        Field[] fields = objClass.getDeclaredFields();
        List<String> names = new ArrayList<>();
        int i = 0;
        for(Field field : fields) {
            if(field.getName().contains("id")) {
                continue;
            }
            names.add(field.getName());
        }
        return names;
    }
}
