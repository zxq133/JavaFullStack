package cn.student.controller;

import cn.student.pojo.Student;
import cn.student.service.StudentService;
import cn.student.util.DatabaseUtil;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainMenu {
    private ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationConfig.xml");
    private StudentService service = (StudentService) context.getBean("studentService");
    private Scanner scaner = new Scanner(System.in);

    public SqlSession getSqlSession() {
        SqlSessionFactory sqlSessionFactory = (SqlSessionFactory) this.context.getBean("sqlSessionFactory");
        return sqlSessionFactory.openSession();
    }
    public void addStudent() {
        Date date = null;

        System.out.print("请输入学生姓名：");
        String sName = scaner.next();
        System.out.print("请输入学生年龄：");
        int sAge = scaner.nextInt();
        scaner.nextLine();
        System.out.print("请输入学生生日（yyyy-MM-dd HH:mm:ss）：");
        String birthday = scaner.nextLine();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            date = sdf.parse(birthday);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        Student student = new Student(sName,sAge,date);
        int size = service.getStudentList().size();
        student.setSid(size + 1);
        Student stu = service.addStudent(student);
        if(stu != null) {
            getSqlSession().commit();
            System.out.println("学生信息添加成功！");
            return;
        }
        System.out.println("学生信息添加失败!");
    }

    public void deleteStudent() {
        this.listStudent();
        System.out.print("请输入要删除的学生编号：");
        int id = scaner.nextInt();
        Student student = service.deleteStudent(id);
        if (student == null) {
            getSqlSession().commit();
            System.out.println("学生信息删除成功！");
            return;
        }
        System.out.println("学生信息删除失败！");
    }

    public void listStudent() {
        System.out.println("学生信息如下：");
        System.out.print("编号\t\t姓名\t\t年龄\t\t生日\n");
        List<Student> students = service.getStudentList();
        for(Student student : students) {
            System.out.printf("%d\t\t%s\t\t%d\t\t%s\n",student.getSid(),student.getName(),student.getAge(), new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(student.getBirthday()));
        }
    }

    public void updateStudent() {
        boolean stop = false;
        List<Object> args = new ArrayList<>();
        StringJoiner joiner = new StringJoiner(",");
        this.listStudent();
        System.out.print("请输入要修改的学生编号：");
        int id = scaner.nextInt();
        System.out.println("可以修改的属性名称如下：");
        List<String> attrNames = DatabaseUtil.getAttrName(Student.class);
        for(String attrName : attrNames) {
            System.out.print(attrName + "    ");
        }
        System.out.print("\n");
        do {
            System.out.print("请输入要修改的学生信息属性：");
            String attN = scaner.next();
            System.out.print("请输入修改后的值：");
            switch(attN.trim()) {
                case "name" : {
                    joiner.add(attN + " = ? ");
                    args.add(scaner.next());
                    break;
                }
                case "age": {
                    joiner.add(attN + " = ? ");
                    args.add(scaner.nextInt());
                    break;
                }
                case "birthday" : {
                    joiner.add(attN + " = ? ");
                    try {
                        scaner.nextLine();
                        String date = scaner.nextLine();
                        args.add(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(date));
                    } catch (ParseException e) {
                        throw new RuntimeException(e);
                    }
                    break;
                }
                default: {
                    System.out.println("输入错误！");
                    continue;
                }
            }
            // System.out.println(joiner.toString());
            System.out.print("是否修改其他属性？(true/false):");
            String temp = scaner.next();
            if("false".equals(temp)) {
                stop = true;
            }
        } while (!stop);
        String setting = joiner.toString();
        Student student = service.putStudent(id, setting, args);
        if(student != null) {
            getSqlSession().commit();
            System.out.println("学生信息修改成功！");
            return;
        }
        System.out.println("学生信息修改失败！");
    }

    public boolean printMenu() {
        boolean flag = false;
        System.out.println("-----------欢迎来到学生管理系统------------");
        System.out.println("1.添加学生");
        System.out.println("2.删除学生");
        System.out.println("3.修改学生");
        System.out.println("4.查看所有学生");
        System.out.println("5.退出");
        System.out.print("请选择：");
        int i = scaner.nextInt();
        switch(i) {
            case 1 : {
                System.out.println("添加学生");
                this.addStudent();
                break;
            }
            case 2 : {
                System.out.println("删除学生");
                this.deleteStudent();
                this.listStudent();
                break;
            }
            case 3 : {
                System.out.println("修改学生");
                this.updateStudent();
                this.listStudent();
                break;
            }
            case 4 : {
                System.out.println("查看所有学生");
                this.listStudent();
                break;
            }
            case 5 : {
                System.out.println("感谢使用！");
                flag = true;
                break;
            }
            default:{
                System.out.println("输入错误！");
            }
        }
        return flag;
    }
    public static void main(String[] args) {
        MainMenu mainMenu = new MainMenu();
        while(true) {
            if(mainMenu.printMenu()) {
                break;
            }
        }
    }
}
